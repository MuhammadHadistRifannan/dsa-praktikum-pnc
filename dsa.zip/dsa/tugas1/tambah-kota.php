<html>
    <form method="post" action="index.php">
            <input type="text" name="nama_kota" placeholder="kota"><br>
            <input type="text" name="nama_bupati" placeholder="nama_bupati"><br>
            <a href="form-input.php">Kembali</a>
    </form>
</html>