<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head><title>Menu Bank</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
    <h2>Menu Bank :</h2>
    <ol>
        <li><a href="proses.php?menu=1">Tambah saldo tabungan 1</a></li>
        <li><a href="proses.php?menu=2">Tambah saldo tabungan 2</a></li>
        <li><a href="proses.php?menu=3">Tambah saldo tabungan 3</a></li>
        <li><a href="proses.php?menu=4">Tambah saldo deposito</a></li>
        <li><a href="proses.php?menu=5">Tampil Saldo</a></li>
    </ol>
</body>
</html>
